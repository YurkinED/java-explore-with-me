package ru.practicum.request.model;

public enum TypeStateRequest {
    CONFIRMED,
    PENDING,
    REJECTED,
    CANCELED
}
