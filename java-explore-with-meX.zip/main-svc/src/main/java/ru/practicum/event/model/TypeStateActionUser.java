package ru.practicum.event.model;

public enum TypeStateActionUser {
    SEND_TO_REVIEW,
    CANCEL_REVIEW
}