package ru.practicum.event.model;

public enum TypeStateActionAdmin {
    PUBLISH_EVENT,
    REJECT_EVENT
}