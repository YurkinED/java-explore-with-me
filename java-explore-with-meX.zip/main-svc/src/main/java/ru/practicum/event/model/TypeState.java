package ru.practicum.event.model;

public enum TypeState {
    PENDING,
    PUBLISHED,
    CANCELED
}