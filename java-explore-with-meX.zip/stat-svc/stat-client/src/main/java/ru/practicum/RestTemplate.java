package ru.practicum;

public class RestTemplate {
}


