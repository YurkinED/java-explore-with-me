package ru.practicum.dao;

public interface EventHits {
    String getApp();

    String getUri();

    Integer getHits();
}
