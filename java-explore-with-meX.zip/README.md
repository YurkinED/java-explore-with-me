# java-explore-with-me

Репозиторий для проекта ExploreWithMe (Юркин Евгений).
Ссылка на пулл реквест: 
https://github.com/YurkinED/java-explore-with-me/pull/5
В данном проекте дополнительна реализована возможность оставлять комментарии к событиям.

